#!/usr/bin/env python3
# Armuzz intro: UI editor 3D fly-through + maskot + partikel X + teks penutup. Semua dari kode.
import sys, os, math, random, subprocess
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageChops
from scipy.ndimage import gaussian_filter
from scipy.interpolate import PchipInterpolator

W, H, FPS, DUR = 1280, 720, 30, 27.0
SW, SH = 2560, 1440
FOC = 1100.0
HERE = os.path.dirname(os.path.abspath(__file__))
INTER = os.environ.get("INTER_DIR", "/usr/share/fonts/opentype/inter") + "/Inter-"
def fnt(style, size): return ImageFont.truetype(f"{INTER}{style}.otf", size)
SERIF = next(p for p in ["/usr/share/fonts/truetype/freefont/FreeSerif.ttf",
                         "/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf"] if os.path.exists(p))
def serif(size): return ImageFont.truetype(SERIF, size)

RED = (255, 52, 78); HOT = (255, 100, 112); DEEP = (150, 18, 38)
def clamp(x, a=0.0, b=1.0): return max(a, min(b, x))
def ease_out(x): x = clamp(x); return 1 - (1 - x) ** 3
def ease_in(x): x = clamp(x); return x ** 3
def ease_io(x): x = clamp(x); return x * x * (3 - 2 * x)
def lerp(a, b, u): return a + (b - a) * u

rng = np.random.default_rng(11)
random.seed(11)

# ----------------------------------------------------------------- maskot
def make_mascot(blink=False):
    s = 2; w, h = 400 * s, 440 * s
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    mask = Image.new("L", (w, h), 0); d = ImageDraw.Draw(mask)
    d.ellipse((60*s, 90*s, 340*s, 400*s), fill=255)
    d.ellipse((105*s, 380*s, 185*s, 425*s), fill=255); d.ellipse((215*s, 380*s, 295*s, 425*s), fill=255)
    d.ellipse((28*s, 230*s, 92*s, 300*s), fill=255); d.ellipse((308*s, 230*s, 372*s, 300*s), fill=255)
    m = np.asarray(mask, np.float32) / 255
    dist = np.sqrt((xx - 160*s) ** 2 + (yy - 190*s) ** 2) / (250 * s)
    t = np.clip(dist, 0, 1.2) / 1.2
    c0 = np.array([255, 120, 128], np.float32); c1 = np.array([205, 22, 52], np.float32)
    col = c0 * (1 - t[..., None]) + c1 * t[..., None]
    rgba = np.concatenate([col, (m * 255)[..., None]], -1).astype(np.uint8)
    im = Image.fromarray(rgba, "RGBA"); d = ImageDraw.Draw(im)
    dk = (38, 8, 16, 255)
    for ex in (150, 250):
        if blink:
            d.arc(((ex-18)*s, 212*s, (ex+18)*s, 240*s), 200, 340, fill=dk, width=6*s)
        else:
            d.ellipse(((ex-15)*s, 200*s, (ex+15)*s, 250*s), fill=dk)
            d.ellipse(((ex-7)*s, 208*s, (ex+3)*s, 220*s), fill=(255, 255, 255, 255))
    d.ellipse((92*s, 252*s, 128*s, 276*s), fill=(255, 150, 160, 130))
    d.ellipse((272*s, 252*s, 308*s, 276*s), fill=(255, 150, 160, 130))
    d.arc((182*s, 244*s, 218*s, 276*s), 20, 160, fill=dk, width=5*s)
    # tanda X di kepala (simbol visual Armuzz)
    cx, cy, r = 200*s, 138*s, 26*s
    for (a, b) in (((cx-r, cy-r), (cx+r, cy+r)), ((cx-r, cy+r), (cx+r, cy-r))):
        d.line((*a, *b), fill=(255, 238, 240, 255), width=13*s)
        for p in (a, b): d.ellipse((p[0]-6.5*s, p[1]-6.5*s, p[0]+6.5*s, p[1]+6.5*s), fill=(255, 238, 240, 255))
    return im.resize((400, 440), Image.LANCZOS)

_ARYA = Image.open(os.path.join(HERE, "mascot_arya.png")).convert("RGBA")
MASCOT = [_ARYA, _ARYA]
SPR_W, SPR_H = _ARYA.size
ANCH = (SPR_W // 2, 454)

# ----------------------------------------------------------------- UI statis
PXS = (2500 - 540) / 27.0
TOOLS = ["home", "select", "hand", "zoom", "rotate", "camera", "rect", "ellipse", "pen", "T", "brush", "stamp", "star", "plus"]
def tx(i): return 220 + i * 100
def icon(d, kind, cx, cy, c):
    w = 3
    if kind == "home": d.polygon([(cx-14, cy+2), (cx, cy-12), (cx+14, cy+2), (cx+10, cy+2), (cx+10, cy+13), (cx-10, cy+13), (cx-10, cy+2)], outline=c, width=w)
    elif kind == "select": d.polygon([(cx-9, cy-13), (cx-9, cy+11), (cx-3, cy+5), (cx+3, cy+15), (cx+7, cy+13), (cx+1, cy+3), (cx+9, cy+3)], fill=c)
    elif kind == "hand":
        d.rounded_rectangle((cx-10, cy-4, cx+10, cy+13), 6, outline=c, width=w)
        for i in range(4): d.line((cx-7+i*5, cy-4, cx-7+i*5, cy-13), fill=c, width=3)
    elif kind == "zoom": d.ellipse((cx-12, cy-12, cx+6, cy+6), outline=c, width=w); d.line((cx+4, cy+4, cx+13, cy+13), fill=c, width=4)
    elif kind == "rotate": d.arc((cx-12, cy-12, cx+12, cy+12), 30, 300, fill=c, width=w); d.polygon([(cx+11, cy-9), (cx+14, cy+2), (cx+3, cy-1)], fill=c)
    elif kind == "camera": d.rounded_rectangle((cx-14, cy-8, cx+14, cy+11), 4, outline=c, width=w); d.ellipse((cx-6, cy-4, cx+6, cy+8), outline=c, width=w)
    elif kind == "rect": d.rectangle((cx-13, cy-10, cx+13, cy+10), outline=c, width=w)
    elif kind == "ellipse": d.ellipse((cx-13, cy-10, cx+13, cy+10), outline=c, width=w)
    elif kind == "pen": d.polygon([(cx-3, cy-14), (cx+8, cy-3), (cx+3, cy+4), (cx-8, cy-7)], outline=c, width=w); d.line((cx+3, cy+4, cx-3, cy+13), fill=c, width=w)
    elif kind == "T": d.text((cx, cy), "T", font=fnt("Bold", 34), fill=c, anchor="mm")
    elif kind == "brush": d.line((cx-11, cy+11, cx+9, cy-9), fill=c, width=6); d.ellipse((cx-15, cy+7, cx-7, cy+15), fill=c)
    elif kind == "stamp": d.rectangle((cx-12, cy+4, cx+12, cy+12), outline=c, width=w); d.ellipse((cx-6, cy-12, cx+6, cy), outline=c, width=w)
    elif kind == "star":
        pts = [(cx + (14 if i % 2 == 0 else 6) * math.sin(i*math.pi/5), cy - (14 if i % 2 == 0 else 6) * math.cos(i*math.pi/5)) for i in range(10)]
        d.polygon(pts, outline=c, width=w)
    elif kind == "plus": d.line((cx-12, cy, cx+12, cy), fill=c, width=4); d.line((cx, cy-12, cx, cy+12), fill=c, width=4)

BARS = [(0, 27, (225, 62, 78), 40), (10, 27, (66, 128, 228), 40), (5, 23, (208, 168, 58), 40), (0, 27, (118, 118, 130), 22)]
LAYERS = ["WEB DEV", "STREAMER", "CONTENT", "STUDENT"]
DIAMONDS = [[3, 8, 12, 16, 20, 24], [11, 13, 17, 19, 22, 25], [6, 9, 14, 18, 21], [2, 10, 15, 23]]
def row_y(i): return 990 + i * 110

def build_static():
    im = Image.new("RGB", (SW, SH), (15, 15, 19)); d = ImageDraw.Draw(im)
    fs, fm, fb = fnt("Regular", 20), fnt("Medium", 22), fnt("SemiBold", 24)
    gray = (150, 150, 162); dim = (110, 110, 122)
    d.rectangle((0, 0, SW, 40), fill=(21, 21, 26))
    x = 24
    for m in ["Armuzz", "File", "Edit", "Composition", "Layer", "Effect", "Animation", "View", "Window", "Help"]:
        d.text((x, 9), m, font=fs, fill=(170, 170, 180)); x += d.textlength(m, font=fs) + 34
    d.rectangle((0, 40, SW, 100), fill=(27, 27, 33))
    for i, k in enumerate(TOOLS): icon(d, k, tx(i), 70, (176, 176, 188))
    x = 1760
    for m in ["Default", "Standard", "Review", "Learn"]:
        d.text((x, 58), m, font=fs, fill=gray); x += d.textlength(m, font=fs) + 36
    d.rounded_rectangle((2230, 52, 2520, 90), 8, fill=(18, 18, 22), outline=(50, 50, 58)); d.text((2250, 59), "Search Help", font=fs, fill=dim)
    # panel kiri
    d.rectangle((0, 100, 520, 900), fill=(20, 20, 25), outline=(38, 38, 46))
    d.text((24, 112), "Project", font=fb, fill=(220, 220, 228)); d.line((20, 150, 140, 150), fill=RED, width=3)
    d.rectangle((60, 190, 160, 290), fill=(226, 80, 96))
    d.text((190, 196), "intro_final.mp4", font=fm, fill=(215, 215, 222))
    d.text((190, 232), "1280 x 720 (1.00)", font=fs, fill=dim); d.text((190, 262), "\u0394 0:00:27:00, 30.00 fps", font=fs, fill=dim)
    for i, n in enumerate(["armuzz_main.mp4", "armuzz_symbol.svg", "overlay_neon.png", "stream_alert.html", "portfolio.zip"]):
        y = 350 + i * 50
        d.rounded_rectangle((26, y, 58, y + 30), 5, outline=(90, 90, 100), width=2); d.text((78, y + 2), n, font=fs, fill=gray)
    # viewer
    d.rectangle((520, 100, 1840, 900), fill=(10, 10, 12), outline=(38, 38, 46))
    d.text((540, 106), "Composition   Comp 1", font=fs, fill=dim)
    d.text((1560, 866), "Full", font=fs, fill=dim); d.text((1650, 866), "Active Camera", font=fs, fill=dim)
    # panel kanan
    d.rectangle((1840, 100, SW, 900), fill=(20, 20, 25), outline=(38, 38, 46))
    d.text((1870, 112), "Preview", font=fs, fill=dim); d.text((2010, 112), "Effects & Presets", font=fb, fill=(220, 220, 228)); d.line((2010, 150, 2230, 150), fill=RED, width=3)
    for i in range(5): d.rounded_rectangle((1870 + i * 70, 170, 1920 + i * 70, 210), 8, fill=(34, 34, 40))
    d.polygon([(1992, 180), (1992, 200), (2008, 190)], fill=(180, 180, 190))
    d.rounded_rectangle((1870, 236, 2520, 276), 8, fill=(15, 15, 19), outline=(50, 50, 58)); d.text((1890, 244), "Search presets", font=fs, fill=dim)
    d.text((1870, 296), "\u25be Animation Presets", font=fb, fill=(200, 200, 208))
    for i, n in enumerate(["Glow", "Glow Pulse", "Glow In \u2014 Text", "Neon Flicker", "Particle Burst"]):
        d.text((1920, 354 + i * 56), n, font=fm, fill=(190, 190, 200))
        d.ellipse((1890, 366 + i * 56, 1904, 380 + i * 56), outline=(110, 110, 120), width=2)
    d.text((1870, 650), "\u25be Obsolete", font=fb, fill=(200, 200, 208)); d.text((1920, 704), "Glow (Legacy)", font=fm, fill=(150, 150, 160))
    # timeline
    d.rectangle((0, 900, SW, SH), fill=(17, 17, 21), outline=(38, 38, 46))
    d.text((24, 916), "0:00:00:00", font=fb, fill=(200, 200, 208))
    for s in range(28):
        x = 540 + s * PXS; major = (s % 5 == 0)
        d.line((x, 940 if major else 946, x, 952), fill=(90, 90, 100), width=2)
        if major: d.text((x + 6, 918), f"{s}s", font=fs, fill=dim)
    d.rectangle((540, 925, 540 + 2 * PXS, 933), fill=(76, 160, 88))
    for i in range(4):
        y = row_y(i)
        d.line((0, y + 62, SW, y + 62), fill=(30, 30, 36), width=2)
        d.rectangle((26, y - 10, 46, y + 10), fill=BARS[i][2]); d.text((66, y - 14), LAYERS[i], font=fm, fill=(200, 200, 208))
        a, b, c, hh = BARS[i]
        d.rounded_rectangle((540 + a * PXS, y - hh // 2, 540 + b * PXS, y + hh // 2), 7, fill=c)
    return im

STATIC = build_static()
HALF = None

# ----------------------------------------------------------------- kamera
class Cam:
    def __init__(s, cx, cy, zoom, yaw, pitch, roll):
        s.cx, s.cy, s.zoom = cx, cy, zoom; s.d = FOC / zoom
        a, b, c = map(math.radians, (pitch, yaw, roll))
        Rx = np.array([[1, 0, 0], [0, math.cos(a), -math.sin(a)], [0, math.sin(a), math.cos(a)]])
        Ry = np.array([[math.cos(b), 0, math.sin(b)], [0, 1, 0], [-math.sin(b), 0, math.cos(b)]])
        Rz = np.array([[math.cos(c), -math.sin(c), 0], [math.sin(c), math.cos(c), 0], [0, 0, 1]])
        s.R = Rx @ Ry @ Rz
    def proj(s, x, y):
        q = s.R @ np.array([x - s.cx, y - s.cy, 0.0]); zc = s.d + q[2]
        return W / 2 + FOC * q[0] / zc, H / 2 + FOC * q[1] / zc, FOC / zc, zc
    def valid(s):
        return all(s.proj(x, y)[3] > 0.3 * s.d for x, y in ((0, 0), (SW, 0), (SW, SH), (0, SH)))

KT = [0, 2.2, 3.4, 5.0, 6.3, 7.6, 8.9, 10.2, 12.3, 13.8, 15.2, 27.0]
KV = {
    "cx":   [1280, 1260, 760, 1250, 1500, 2150, 1180, 1000, 1650, 1700, 1180, 1180],
    "cy":   [720, 700, 60, 70, 120, 380, 500, 1130, 1130, 700, 490, 490],
    "zoom": [0.5, 0.54, 1.05, 1.10, 1.0, 1.0, 0.92, 0.95, 0.95, 0.8, 1.0, 1.0],
    "yaw":  [0, -2, -22, 10, 24, 30, -20, -18, 14, 10, 0, 0],
    "pitch": [0, 4, 52, 50, 38, 14, 24, 50, 46, 25, 0, 0],
    "roll": [0, 0, -7, 5, 8, 10, -4, 3, -3, 2, 0, 0],
}
CF = {k: PchipInterpolator(KT, v) for k, v in KV.items()}
def make_cam(t):
    """Kamera dengan pembatas sudut kontinu agar tidak meloncat antar-frame.

    Versi sebelumnya mengurangi sudut kamera 10% per percobaan. Saat kamera
    melewati batas validitas, perubahan diskret itu dapat terlihat sebagai
    snap/glitch. Binary search menjaga sudut sedekat mungkin ke nilai target
    sambil memastikan seluruh sudut lembar berada di depan kamera.
    """
    v = {k: float(f(t)) for k, f in CF.items()}
    def build(scale):
        return Cam(v["cx"], v["cy"], v["zoom"],
                   v["yaw"] * scale, v["pitch"] * scale, v["roll"] * scale)

    full = build(1.0)
    if full.valid():
        return full

    lo, hi = 0.0, 1.0
    for _ in range(16):
        mid = (lo + hi) * 0.5
        if build(mid).valid():
            lo = mid
        else:
            hi = mid
    return build(lo * 0.995)

def persp_coeffs(src, dst):
    A, B = [], []
    for (x, y), (u, v) in zip(src, dst):
        A.append([u, v, 1, 0, 0, 0, -u * x, -v * x]); B.append(x)
        A.append([0, 0, 0, u, v, 1, -u * y, -v * y]); B.append(y)
    return np.linalg.solve(np.array(A, float), np.array(B, float))

def warp_sheet(sheet, cam):
    k = 0.5 if cam.zoom < 0.75 else 1.0
    img = sheet.reduce(2) if k == 0.5 else sheet
    rgba = img.convert("RGBA")
    corners = [(0, 0), (SW, 0), (SW, SH), (0, SH)]
    dst = [cam.proj(x, y)[:2] for x, y in corners]
    src = [(x * k, y * k) for x, y in corners]
    co = persp_coeffs(src, dst)
    return rgba.transform((W, H), Image.PERSPECTIVE, tuple(co), resample=Image.BICUBIC, fillcolor=(0, 0, 0, 0))

# ----------------------------------------------------------------- maskot: gerak
def IDX(i): return (tx(i), 44)
def play_x(t): return 600 + (2300 - 600) * ease_io((t - 10.2) / 4.0)
A0 = (1180, 610)
HOPS = [
    (2.4, 3.1, A0, IDX(1), 260),
    (3.35, 3.8, IDX(1), IDX(3), 150),
    (3.95, 4.4, IDX(3), IDX(6), 150),
    (4.55, 4.95, IDX(6), IDX(7), 110),
    (5.1, 5.6, IDX(7), IDX(9), 130),
    (6.5, 7.3, IDX(9), (2250, 340), 380),
    (9.6, 10.3, (2250, 340), (play_x(10.3), 904), 520),
    (14.0, 14.75, (play_x(14.0), 904), (1790, 848), 300),
]
def mascot_state(t):
    """return feet_x, feet_y, hop_h, sx, sy, alpha_scale"""
    sx = sy = 1.0; h = 0.0
    cur = A0; inflight = False
    for i, (t0, t1, a, b, pk) in enumerate(HOPS):
        if t0 <= t < t1:
            u = (t - t0) / (t1 - t0)
            x = lerp(a[0], b[0], u); y = lerp(a[1], b[1], u)
            if i == 6: x = lerp(a[0], play_x(t), u)
            h = 4 * pk * u * (1 - u)
            sy = 1 + 0.16 * abs(1 - 2 * u); sx = 1 / sy ** 0.6
            return x, y, h, sx, sy, 1.0
        if t >= t1: cur = b
    # idle / riding
    x, y = cur
    if 10.3 <= t < 14.0: x, y = play_x(t), 904
    # antisipasi crouch & landing squash
    for (t0, t1, a, b, pk) in HOPS:
        if t0 - 0.16 <= t < t0:
            c = ease_io((t - (t0 - 0.16)) / 0.16); sy = 1 - 0.22 * c; sx = 1 / sy ** 0.7
        if 0 <= t - t1 < 0.35:
            dt = t - t1; sy = 1 - 0.24 * math.exp(-dt * 12) * math.cos(dt * 26); sx = 1 / sy ** 0.7
    if sx == 1.0 and sy == 1.0: sy = 1 + 0.03 * math.sin(2 * math.pi * 0.9 * t); sx = 1 / sy ** 0.5
    a = 1.0
    if t > 15.15: a = 1 - ease_in((t - 15.15) / 0.25)
    return x, y, h, sx, sy, a

def active_tool(t):
    """(idx_terpilih_merah, idx_hover)"""
    sel = None; hover = None
    if t >= 5.6: sel = 9
    elif 4.4 <= t < 5.1: sel = 6
    for (t0, t1, a, b, pk) in HOPS[:5]:
        if t1 <= t < t0 + 1.0 and t < 6.5:
            idx = (b[0] - 220) // 100
            hover = idx
    # hover = tool tempat berdiri sekarang
    cur = None
    for (t0, t1, a, b, pk) in HOPS[:5]:
        if t >= t1: cur = (b[0] - 220) // 100
    return sel, cur if t < 6.5 else None

# ----------------------------------------------------------------- scene (isi viewer & frame penuh)
yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
RN = np.sqrt(((xx - 640) / 640) ** 2 + ((yy - 360) / 640) ** 2)
NOISE = rng.random((H, W)).astype(np.float32)
ORB = np.exp(-(RN / 0.62) ** 2)[..., None] * np.array([150, 26, 44], np.float32)
BASE_DARK = np.array([11, 9, 11], np.float32)
VIGN = (1 - 0.35 * np.clip(np.sqrt(((xx - 640) / 700) ** 2 + ((yy - 360) / 420) ** 2), 0, 1.3) ** 2)[..., None].astype(np.float32)

def make_x_icon(size=120):
    s = 4; n = size * s
    im = Image.new("RGBA", (n, n), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    p = n * 0.22
    for col, wd in (((255, 70, 92, 255), n * 0.17), ((255, 190, 196, 255), n * 0.06)):
        for a, b in (((p, p), (n - p, n - p)), ((p, n - p), (n - p, p))):
            d.line((*a, *b), fill=col, width=int(wd))
            for q in (a, b): d.ellipse((q[0]-wd/2, q[1]-wd/2, q[0]+wd/2, q[1]+wd/2), fill=col)
    glow = im.filter(ImageFilter.GaussianBlur(n * 0.06))
    out = Image.alpha_composite(glow, im)
    return out.resize((size, size), Image.LANCZOS)
ICON_X = make_x_icon(120)

def typed_text(img, text, font, pos, color, t, t0, cps, align="center", soft=6, rise=10, am=1.0):
    prog = (t - t0) * cps
    if prog <= 0 or am <= 0: return
    total = font.getlength(text); x0 = pos[0] - total / 2 if align == "center" else pos[0]
    asc, desc = font.getmetrics(); hb = asc + desc; pad = 40
    bx, by, bw, bh = int(x0 - pad), int(pos[1] - pad), int(total + 2 * pad), int(hb + 2 * pad)
    sharp = Image.new("RGBA", (bw, bh), (0, 0, 0, 0)); sl = Image.new("RGBA", (bw, bh), (0, 0, 0, 0))
    ds, dl = ImageDraw.Draw(sharp), ImageDraw.Draw(sl)
    for i, ch in enumerate(text):
        a = clamp(prog - i)
        if a <= 0: break
        px = pad + font.getlength(text[:i]); s = clamp((a - 0.35) / 0.65); ry = (1 - ease_out(a)) * rise
        ds.text((px, pad + ry), ch, font=font, fill=tuple(int(c) for c in color) + (int(255 * s * am),))
        dl.text((px, pad + ry), ch, font=font, fill=tuple(int(c) for c in color) + (int(210 * a * (1 - s) * am),))
    sl = sl.filter(ImageFilter.GaussianBlur(soft))
    img.paste(sl, (bx, by), sl); img.paste(sharp, (bx, by), sharp)

def layer_paste(img, layer, pos, a, blur=0.0, rise=0.0):
    if a <= 0.01: return
    if blur > 0.3: layer = layer.filter(ImageFilter.GaussianBlur(blur))
    if a < 1:
        al = layer.getchannel("A").point(lambda v: int(v * a)); layer = layer.copy(); layer.putalpha(al)
    img.paste(layer, (int(pos[0]), int(pos[1] + rise)), layer)

def make_title_layer():
    f = fnt("SemiBold", 74); tw = f.getlength("Armuzz"); icon_s = 84
    lw = int(icon_s + 24 + tw + 80); lh = 170
    L = Image.new("RGBA", (lw, lh), (0, 0, 0, 0)); d = ImageDraw.Draw(L)
    L.alpha_composite(ICON_X.resize((icon_s, icon_s), Image.LANCZOS), (40, (lh - icon_s) // 2))
    d.text((40 + icon_s + 24, lh // 2), "Armuzz", font=f, fill=(255, 255, 255, 255), anchor="lm")
    return L
TITLE_L = make_title_layer()
def make_chip(txt):
    f = fnt("SemiBold", 22); tw = f.getlength(txt); w, h = int(tw + 44), 46
    L = Image.new("RGBA", (w + 40, h + 40), (0, 0, 0, 0)); d = ImageDraw.Draw(L)
    d.rounded_rectangle((20, 20, 20 + w, 20 + h), 23, fill=(40, 8, 16, 150), outline=(255, 90, 106, 255), width=2)
    d.text((20 + w / 2, 20 + h / 2), txt, font=f, fill=(255, 226, 230, 255), anchor="mm")
    return L
CHIPS = [make_chip(c) for c in ("WEB DEV", "STREAMER", "INFORMATICS")]
def make_name_layer():
    f = fnt("Medium", 42); txt = "Arya Musthofa Roja"; hl = {0, 1, 5, 6}
    L = Image.new("RGBA", (int(f.getlength(txt)) + 80, 100), (0, 0, 0, 0)); d = ImageDraw.Draw(L)
    for i, ch in enumerate(txt):
        d.text((40 + f.getlength(txt[:i]), 50), ch, font=f, fill=(255, 100, 112, 255) if i in hl else (238, 228, 231, 255), anchor="lm")
    return L
def make_cap_layer():
    f = fnt("Regular", 27); segs = [("Ar", (255, 100, 112)), ("(ya) + ", (180, 148, 155)), ("Mu", (255, 100, 112)), ("(sthofa)  =  ", (180, 148, 155)), ("Armuzz", (255, 255, 255))]
    tot = sum(f.getlength(t_) for t_, _ in segs); L = Image.new("RGBA", (int(tot) + 80, 70), (0, 0, 0, 0)); d = ImageDraw.Draw(L); x = 40
    for t_, c in segs: d.text((x, 35), t_, font=f, fill=c + (255,), anchor="lm"); x += f.getlength(t_)
    return L
NAME_L = make_name_layer(); CAP_L = make_cap_layer()

# partikel X
def build_particles(N=16000):
    m = Image.new("L", (W, H), 0); ImageDraw.Draw(m).text((640, 372), "X", font=fnt("ExtraBold", 700), fill=255, anchor="mm")
    pts = np.argwhere(np.asarray(m) > 128)
    sel = pts[rng.integers(0, len(pts), N)]
    ty, tx_ = sel[:, 0].astype(np.float32) + rng.normal(0, .4, N), sel[:, 1].astype(np.float32) + rng.normal(0, .4, N)
    ang = rng.random(N) * 2 * np.pi; rad = rng.uniform(350, 1100, N)
    return dict(tx=tx_, ty=ty, sx=tx_ + rad * np.cos(ang), sy=ty + rad * np.sin(ang) * .6,
                dl=rng.uniform(0, 1.6, N), du=rng.uniform(1.1, 1.8, N), b=rng.uniform(.45, 1.0, N),
                ph=rng.uniform(0, 6.28, N), vx=rng.normal(0, 150, N), vy=rng.normal(-120, 110, N), dd=rng.uniform(0, 1.5, N))
PT = build_particles()
T_ASM, T_DIS = 15.0, 19.6
PCOL = np.array([255, 84, 100], np.float32)
TITLE_MASK = (1 - 0.93 * np.maximum(np.exp(-(((xx - 640) / 360) ** 4 + ((yy - 320) / 78) ** 2)), np.exp(-(((xx - 640) / 360) ** 4 + ((yy - 432) / 78) ** 2))))[..., None].astype(np.float32)

def particles_layer(t):
    P = PT
    p = np.clip((t - T_ASM - P["dl"]) / P["du"], 0, 1); p = 1 - (1 - p) ** 3
    x = P["sx"] + (P["tx"] - P["sx"]) * p; y = P["sy"] + (P["ty"] - P["sy"]) * p
    al = p.copy()
    if t > T_DIS:
        dt = t - T_DIS
        x = x + P["vx"] * dt + 40 * np.sin(dt * 2 + P["ph"]) * dt; y = y + P["vy"] * dt
        al = al * np.clip(1 - (dt - P["dd"] * 0.6) / 0.9, 0, 1)
    tw = 0.72 + 0.28 * np.sin(t * 3.2 + P["ph"])
    val = (al * P["b"] * tw).astype(np.float32)
    ix = np.clip(x.astype(np.int32), 0, W - 1); iy = np.clip(y.astype(np.int32), 0, H - 1)
    buf = np.zeros((H, W), np.float32); np.add.at(buf, (iy, ix), val)
    sharp = gaussian_filter(buf, 0.7) * 2.6
    small = buf.reshape(H // 2, 2, W // 2, 2).sum((1, 3))
    halo = np.asarray(Image.fromarray(gaussian_filter(small, 3.0)).resize((W, H), Image.BILINEAR)) * 7.0
    return (sharp + halo * 0.30)[..., None] * PCOL * TITLE_MASK

def orb_level(t):
    return float(np.interp(t, [9.3, 10.5, 14.4, 15.2, 19.4, 21.8, 22.5, 27], [0, .75, .8, 1.0, 1.0, .45, .3, .3]))

F_ARM = fnt("ExtraBold", 150)
def armuzz_word(img, t, color, am=1.0):
    asc, desc = F_ARM.getmetrics()
    typed_text(img, "ARMUZZ", F_ARM, (640, 360 - (asc + desc) / 2), color, t, 6.2, 8.5, soft=8, rise=16, am=am)

def white_scene(t):
    base = 242 - 22 * np.clip(RN, 0, 1.2) ** 2
    img = np.repeat(base[..., None], 3, -1).astype(np.float32)
    g = ease_out((t - 7.4) / 1.8)
    if g > 0:
        sc_ = 0.55 + 0.45 * g
        rr = np.sqrt(((xx - 640) / 560) ** 2 + ((yy - 360) / 230) ** 2) / sc_
        a = 0.95 * np.exp(-rr ** 3) * (0.80 + 0.20 * NOISE) * min(1.0, g * 1.6)
        img = img * (1 - a[..., None]) + np.array([120, 14, 30], np.float32) * a[..., None]
    pil = Image.fromarray(np.clip(img, 0, 255).astype(np.uint8))
    gg = ease_io((t - 7.4) / 1.4)
    col = tuple(int(lerp(28, 255, gg) * 1) for _ in range(3))
    armuzz_word(pil, t, col)
    return pil

def dark_scene(t):
    o = orb_level(t)
    img = BASE_DARK + ORB * o
    if T_ASM - 0.1 <= t < 22.0: img = img + particles_layer(t)
    pil = Image.fromarray(np.clip(img, 0, 255).astype(np.uint8))
    # kata ARMUZZ tetap ada sebentar lalu hilang
    if 9.3 <= t < 11.2: armuzz_word(pil, t, (255, 255, 255), am=1 - ease_io((t - 10.5) / 0.7))
    # preview teks akhir (scrub timeline)
    if 10.8 <= t < 15.1:
        am = 1 - ease_io((t - 14.3) / 0.7)
        typed_text(pil, "Hi, I'm Armuzz", fnt("Medium", 30), (120, 250), (205, 170, 176), t, 10.8, 12, align="left", soft=3, rise=6, am=am)
        typed_text(pil, "Code it. Stream it. Ship it.", serif(56), (120, 292), (255, 255, 255), t, 11.9, 12, align="left", soft=4, rise=8, am=am)
    # hero
    if 15.2 <= t < 20.6:
        a = ease_out((t - 15.4) / 1.0) * (1 - ease_io((t - 19.8) / 0.8))
        hf = 1 - ease_io((t - 19.8) / 0.8)
        layer_paste(pil, TITLE_L, (640 - TITLE_L.width / 2, 320 - TITLE_L.height / 2), a, blur=(1 - a) * 12, rise=(1 - a) * 18)
        na = ease_out((t - 16.4) / 0.7) * hf
        layer_paste(pil, NAME_L, (640 - NAME_L.width / 2, 408 - NAME_L.height / 2), na, blur=(1 - na) * 10, rise=(1 - na) * 14)
        ca_ = ease_out((t - 17.3) / 0.7) * hf
        layer_paste(pil, CAP_L, (640 - CAP_L.width / 2, 458 - CAP_L.height / 2), ca_, blur=(1 - ca_) * 8, rise=(1 - ca_) * 10)
        for i, c in enumerate(CHIPS):
            ca = ease_out((t - (18.2 + i * 0.25)) / 0.6) * hf
            layer_paste(pil, c, (640 + (i - 1) * 215 - c.width / 2, 530 - c.height / 2), ca, blur=(1 - ca) * 8, rise=(1 - ca) * 14)
    # penutup
    if 15.15 <= t < 16.3:
        k = t - 15.15
        arr = np.asarray(pil, np.float32)
        ring = np.exp(-((RN * 640 - k * 1500) / 14) ** 2) * (1 - clamp(k / 1.0)) * 170
        flash = 90 * max(0.0, 1 - k / 0.25)
        arr = arr + ring[..., None] * np.array([1.0, 0.45, 0.5], np.float32) + flash
        pil = Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8))
    if t >= 21.7:
        fin = 1 - ease_io((t - 26.55) / 0.45)
        f1, f2 = fnt("Medium", 34), serif(70)
        W2 = f2.getlength("Code it. Stream it. Ship it."); x0 = (640 - W2 / 2)
        a_icon = ease_out((t - 21.8) / 0.8) * fin
        layer_paste(pil, ICON_X.resize((54, 54), Image.LANCZOS), (x0 - 6, 258), a_icon, blur=(1 - a_icon) * 8)
        typed_text(pil, "Hi, I'm Armuzz", f1, (x0 + 56, 264), (205, 170, 176), t, 21.9, 12, align="left", soft=3, rise=6, am=fin)
        typed_text(pil, "Code it. Stream it. Ship it.", f2, (x0, 318), (255, 255, 255), t, 22.6, 16, align="left", soft=5, rise=10, am=fin)
        typed_text(pil, "Arya Musthofa Roja", fnt("Medium", 30), (x0 + 4, 392), (228, 198, 204), t, 24.0, 28, align="left", soft=3, rise=4, am=fin)
        typed_text(pil, "armuzzdev.infinityfreeapp.com", fnt("Regular", 27), (x0 + 4, 442), (170, 140, 148), t, 24.7, 30, align="left", soft=3, rise=4, am=fin)
    return pil

def scene_frame(t):
    if t < 9.3: return white_scene(t)
    if t < 10.5:
        a = ease_io((t - 9.3) / 1.2)
        return Image.blend(white_scene(t), dark_scene(t), a)
    return dark_scene(t)

# ----------------------------------------------------------------- sheet dinamis + frame
def blend_rect(img, box, color, alpha):
    w, h = box[2] - box[0], box[3] - box[1]
    img.paste(color, box, Image.new("L", (w, h), int(255 * alpha)))

def sheet_for(t):
    im = STATIC.copy(); d = ImageDraw.Draw(im)
    im.paste(scene_frame(t), (540, 130))
    sel, hov = active_tool(t)
    if hov is not None and hov != sel: blend_rect(im, (tx(hov) - 36, 46, tx(hov) + 36, 96), (255, 255, 255), 0.10)
    if sel is not None:
        blend_rect(im, (tx(sel) - 36, 46, tx(sel) + 36, 96), RED, 0.55); d.rounded_rectangle((tx(sel) - 36, 46, tx(sel) + 36, 96), 8, outline=RED, width=3)
    if t >= 7.35:
        blend_rect(im, (1850, 340, 2550, 394), RED, 0.35); d.rectangle((1850, 340, 1856, 394), fill=RED)
        d.rounded_rectangle((1870 + 2 * 70, 170, 1920 + 2 * 70, 210), 8, fill=RED)
        d.polygon([(2022, 180), (2022, 200), (2038, 190)], fill=(255, 255, 255))
    px = play_x(t); ct = (px - 540) / PXS
    for i, row in enumerate(DIAMONDS):
        for s in row:
            xx_ = 540 + s * PXS; yy_ = row_y(i) + 34; lit = px >= xx_
            d.polygon([(xx_, yy_ - 9), (xx_ + 9, yy_), (xx_, yy_ + 9), (xx_ - 9, yy_)], fill=(255, 120, 132) if lit else (80, 80, 92))
    d.line((px, 925, px, 1420), fill=(255, 92, 112), width=3)
    d.polygon([(px - 12, 905), (px + 12, 905), (px + 12, 925), (px, 940), (px - 12, 925)], fill=(255, 92, 112))
    d.text((1180, 868), f"0:00:{int(ct):02d}:{int((ct % 1) * 30):02d}", font=fnt("Medium", 26), fill=(232, 232, 238), anchor="mm")
    return im

yb, xb = np.mgrid[0:H, 0:W].astype(np.float32)
rb = np.sqrt(((xb - 640) / 900) ** 2 + ((yb - 330) / 600) ** 2); gb = np.clip(1 - rb, 0, 1) ** 2
BG = Image.fromarray(np.stack([8 + 34 * gb, 5 + 8 * gb, 7 + 13 * gb], -1).astype(np.uint8))
DUST = [(random.random() * W, random.random() * H, random.uniform(1, 3), random.uniform(6, 22)) for _ in range(90)]
grng = np.random.default_rng(5)

def post(frame):
    small = frame.resize((320, 180), Image.BILINEAR).point(lambda v: max(0, v - 165) * 1.5)
    bloom = small.filter(ImageFilter.GaussianBlur(6)).resize((W, H), Image.BILINEAR)
    frame = ImageChops.add(frame, bloom)
    a = np.asarray(frame, np.float32) * VIGN + grng.normal(0, 2.0, (H, W, 1)).astype(np.float32)
    return Image.fromarray(np.clip(a, 0, 255).astype(np.uint8))

def world_frame(t):
    cam = make_cam(t)
    fr = BG.copy(); dd = ImageDraw.Draw(fr)
    for (x, y, r, sp) in DUST:
        yy_ = (y - t * sp) % H; c = 60 + int(40 * math.sin(t + x)); dd.ellipse((x - r/2, yy_ - r/2, x + r/2, yy_ + r/2), fill=(c, int(c * .55), int(c * .6)))
    wp = warp_sheet(sheet_for(t), cam); fr.paste(wp, (0, 0), wp)
    mx, my, h, sx, sy, al = mascot_state(t)
    if al > 0.01:
        u, v, sc, zc = cam.proj(mx, my)
        sx = 1 + (sx - 1) * 0.55; sy = 1 + (sy - 1) * 0.55
        scale = 0.5 * sc
        spr = MASCOT[0]
        w_, h_ = max(2, int(SPR_W * scale * sx * al)), max(2, int(SPR_H * scale * sy * al))
        im = spr.resize((w_, h_), Image.BILINEAR)
        ax, ay = ANCH[0] / SPR_W * w_, ANCH[1] / SPR_H * h_
        vy = v - h * sc
        sh = Image.new("RGBA", (int(300 * scale) + 4, int(36 * scale) + 4), (0, 0, 0, 0))
        ImageDraw.Draw(sh).ellipse((0, 0, sh.width - 1, sh.height - 1), fill=(0, 0, 0, int(110 * (1 - clamp(h / 300) * .7))))
        fr.paste(sh, (int(u - sh.width / 2), int(v - sh.height / 2)), sh)
        fr.paste(im, (int(u - ax), int(vy - ay)), im)
    return fr

def render_frame(t):
    if t >= 15.3:
        fr = scene_frame(t)
    elif t >= 15.0:
        a = (t - 15.0) / 0.3
        fr = Image.blend(world_frame(t), scene_frame(t), a)
    else:
        fr = world_frame(t)
    if 15.2 <= t < 15.7:
        k = (t - 15.2) / 0.5; amp = 14 * (1 - k) ** 2
        fr = ImageChops.offset(fr, int(amp * math.sin(k * 40)), int(amp * math.cos(k * 33)))
    f = post(fr)
    if t < 0.5: f = Image.blend(Image.new("RGB", (W, H), (0, 0, 0)), f, ease_out(t / 0.5))
    return f

if __name__ == "__main__":
    mode = sys.argv[1]
    if mode == "still":
        os.makedirs(os.path.join(HERE, "stills"), exist_ok=True)
        for s in sys.argv[2:]:
            render_frame(float(s)).save(os.path.join(HERE, "stills", f"t{float(s):05.2f}.png"))
        print("ok")
    elif mode == "chunk":
        a, b, out = int(sys.argv[2]), int(sys.argv[3]), sys.argv[4]
        pr = subprocess.Popen(["ffmpeg", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                               "-c:v", "libx264", "-preset", "veryfast", "-crf", "16", "-pix_fmt", "yuv420p", "-g", "30", out],
                              stdin=subprocess.PIPE, stderr=subprocess.DEVNULL)
        for i in range(a, b): pr.stdin.write(render_frame(i / FPS).tobytes())
        pr.stdin.close(); pr.wait(); print("chunk done", a, b)
    elif mode == "video":
        out = sys.argv[2]
        pr = subprocess.Popen(["ffmpeg", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                               "-c:v", "libx264", "-preset", "veryfast", "-crf", "16", "-pix_fmt", "yuv420p", out],
                              stdin=subprocess.PIPE, stderr=subprocess.DEVNULL)
        n = int(DUR * FPS)
        for i in range(n):
            pr.stdin.write(render_frame(i / FPS).tobytes())
            if i % 30 == 0: print(f"{i}/{n}", flush=True)
        pr.stdin.close(); pr.wait(); print("done")
