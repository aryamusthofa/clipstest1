#!/usr/bin/env python3
# Audio sintesis untuk intro Armuzz: SFX disinkronkan dengan kejadian visual + bed musik placeholder.
# Pakai:  python3 armuzz_audio.py out.wav [path_musik_opsional]
import sys, math, subprocess
import numpy as np
from scipy.signal import butter, sosfilt
from scipy.io import wavfile

SR = 44100; DUR = 27.0; N = int(SR * DUR)
rng = np.random.default_rng(3)
SFX = [np.zeros(N, np.float32), np.zeros(N, np.float32)]
BED = [np.zeros(N, np.float32), np.zeros(N, np.float32)]

def place(bus, sig, t0, gain=1.0, pan=0.0):
    i = int(t0 * SR)
    if i >= N or i < 0: return
    sig = np.asarray(sig, np.float32)[:N - i]
    a = (pan + 1) * math.pi / 4
    bus[0][i:i + len(sig)] += sig * gain * math.cos(a); bus[1][i:i + len(sig)] += sig * gain * math.sin(a)

def tv(d): return np.arange(int(d * SR)) / SR
def sos_bp(lo, hi): return butter(2, [lo, min(hi, SR / 2 - 200)], btype="band", fs=SR, output="sos")
def lp(x, fc, o=2): return sosfilt(butter(o, fc, btype="low", fs=SR, output="sos"), x)
def hp(x, fc, o=2): return sosfilt(butter(o, fc, btype="high", fs=SR, output="sos"), x)

def sweep_noise(dur, f0, f1):
    n = int(dur * SR); noise = rng.normal(0, 1, n); out = np.zeros(n)
    hop = int(0.04 * SR); win = np.hanning(2 * hop)
    for k in range(0, n - 2 * hop, hop):
        fc = f0 * (f1 / f0) ** (k / n)
        out[k:k + 2 * hop] += sosfilt(sos_bp(fc * 0.7, fc * 1.45), noise[k:k + 2 * hop] * win)
    return out

def whoosh(dur, f0, f1):
    s = sweep_noise(dur, f0, f1)
    return s * np.sin(np.pi * np.linspace(0, 1, len(s))) ** 2 * 0.9

def pop(f0, f1, dur=0.16):
    t = tv(dur); f = f1 + (f0 - f1) * np.exp(-t * 24); ph = 2 * np.pi * np.cumsum(f) / SR
    return np.sin(ph) * np.exp(-t * 20) + hp(rng.normal(0, 1, len(t)), 3000) * np.exp(-t * 400) * 0.25

def boing(dur=0.14):
    t = tv(dur); f = 180 + 360 * (t / dur) ** 0.8; ph = 2 * np.pi * np.cumsum(f) / SR
    return np.sin(ph) * np.exp(-t * 14) * np.minimum(1, t * 400)

def click():
    t = tv(0.03); return hp(rng.normal(0, 1, len(t)), 2500) * np.exp(-t * 400) * 0.8 + np.sin(2 * np.pi * 2300 * t) * np.exp(-t * 300) * 0.4

def bell(f, dur=1.4):
    t = tv(dur); idx = 1.6 * np.exp(-t * 4)
    s = np.sin(2 * np.pi * f * t + idx * np.sin(2 * np.pi * f * 3.5 * t)) + 0.25 * np.sin(2 * np.pi * f * 2.01 * t)
    return s * np.exp(-t * (3.2 / (dur / 1.2))) * np.minimum(1, t * 800)

def boom(dur=2.8):
    t = tv(dur); f = 36 + 70 * np.exp(-t * 9); ph = 2 * np.pi * np.cumsum(f) / SR
    s = np.tanh(2.6 * np.sin(ph)) * np.exp(-t * 1.5)
    s += lp(rng.normal(0, 1, len(t)), 900) * np.exp(-t * 4.5) * 0.7
    s += hp(rng.normal(0, 1, len(t)), 2500) * np.exp(-t * 22) * 0.45
    return s

def riser(dur):
    n = int(dur * SR); t = tv(dur); u = np.linspace(0, 1, n)
    nz = sweep_noise(dur, 300, 9000)[:n]; f = 200 * (1800 / 200) ** u; ph = 2 * np.pi * np.cumsum(f) / SR
    return (nz * 0.8 + np.sin(ph) * 0.25) * (u ** 2.2)

def downlifter(dur):
    n = int(dur * SR); u = np.linspace(0, 1, n)
    return sweep_noise(dur, 8000, 300)[:n] * (1 - u) ** 1.6 * 0.8

def pad(freqs, dur, fc=1800):
    t = tv(dur); s = np.zeros(len(t))
    for f in freqs:
        for d in (0.994, 1.0, 1.006):
            s += 2 * ((f * d * t) % 1) - 1
    s = lp(s / (len(freqs) * 3), fc)
    return s * np.minimum(1, t / 0.3) * np.minimum(1, (dur - t) / 0.5)

def pluck(f, dur=0.28):
    t = tv(dur); s = (2 * ((f * t) % 1) - 1) * np.exp(-t * 13)
    return lp(s, 3200) * np.minimum(1, t * 600)

def bass(f, dur):
    t = tv(dur); s = np.sin(2 * np.pi * f * t) + 0.45 * (2 * ((f * t) % 1) - 1)
    return lp(s, 380) * np.minimum(1, t * 300) * np.minimum(1, (dur - t) * 60)

def kick():
    t = tv(0.4); f = 46 + 120 * np.exp(-t * 30); ph = 2 * np.pi * np.cumsum(f) / SR
    return np.sin(ph) * np.exp(-t * 9) + hp(rng.normal(0, 1, len(t)), 2000) * np.exp(-t * 300) * 0.2

def hat(dec=60):
    t = tv(0.12); return hp(rng.normal(0, 1, len(t)), 7000) * np.exp(-t * dec) * 0.5

def clap():
    t = tv(0.25); s = np.zeros(len(t)); nz = sosfilt(sos_bp(1200, 3500), rng.normal(0, 1, len(t)))
    for o in (0, 0.012, 0.024): 
        i = int(o * SR); s[i:] += nz[:len(t) - i] * np.exp(-t[:len(t) - i] * 60) * 0.7
    return s + nz * np.exp(-t * 14) * 0.5

# ------------------------------------------------------------------ musik (bed)
BPM = 110; BEAT = 60 / BPM; DROP = 15.2
CH = [[261.63, 311.13, 392.00], [207.65, 261.63, 311.13], [196.00, 233.08, 311.13], [233.08, 293.66, 349.23]]
ROOT = [65.41, 51.91, 77.78, 58.27]
def chord_at(t): return int(max(0, t) / (4 * BEAT)) % 4

def build_bed():
    gp = lambda t: float(np.interp(t, [0, 2, 15.1, 15.2, 19.4, 21.6, 24.8, 27], [0, .45, .55, .9, .9, .55, .5, 0]))
    t = 0.0; k = 0
    while t < DUR:
        c = chord_at(t); place(BED, pad(CH[c], 4 * BEAT + 0.5, fc=1400 if t < DROP else 2600), t, gp(t) * 0.5, pan=0)
        t += 4 * BEAT
    # arp
    pat = [0, 1, 2, 1, 2, 1, 0, 1]; ts = 2.4; step = BEAT / 2; j = 0
    while ts < 19.6:
        c = chord_at(ts); g = float(np.interp(ts, [2.4, 10, 15.1, 15.2, 19.4], [.16, .22, .30, .42, .42]))
        place(BED, pluck(CH[c][pat[j % 8] % 3] * 2), ts, g, pan=0.3 if j % 2 else -0.3); ts += step; j += 1
    # drum build + drop
    tb = DROP - BEAT * 5
    while tb < DROP - 0.01:
        place(BED, kick(), tb, float(np.interp(tb, [DROP - 5 * BEAT, DROP], [.25, .6]))); tb += BEAT
    td = DROP; kk = 0
    while td < 19.6:
        place(BED, kick(), td, 0.9)
        place(BED, hat(), td + BEAT / 2, 0.25, pan=0.4); place(BED, hat(), td, 0.12, pan=-0.4)
        if kk % 2 == 1: place(BED, clap(), td, 0.35)
        c = chord_at(td)
        place(BED, bass(ROOT[c], BEAT / 2 - 0.02), td, 0.55); place(BED, bass(ROOT[c], BEAT / 2 - 0.02), td + BEAT / 2, 0.45)
        td += BEAT; kk += 1
    # sidechain
    tt = np.arange(N) / SR; ph = (tt - DROP) % BEAT
    duck = np.where((tt >= DROP - 5 * BEAT) & (tt < 19.6), 1 - 0.5 * np.exp(-ph / 0.12), 1.0).astype(np.float32)
    for ch in range(2): BED[ch] *= duck
    # akhir: bel lembut
    for off, f in enumerate([523.25, 622.25, 783.99, 932.33, 1174.66]):
        place(BED, bell(f, 1.8), 21.95 + off * 0.17, 0.12, pan=-0.4 + off * 0.2)
    for off, f in enumerate([523.25, 783.99, 1046.5]):
        place(BED, bell(f, 3.0), 24.4 + off * 0.05, 0.14, pan=-0.2 + off * 0.2)

# ------------------------------------------------------------------ SFX (disinkronkan dengan visual)
def play_x_time(xd):
    for tt_ in np.linspace(10.2, 14.2, 800):
        u = min(max((tt_ - 10.2) / 4.0, 0), 1); px = 600 + 1700 * (u * u * (3 - 2 * u))
        if px >= xd: return tt_
    return None

def build_sfx():
    cam = [(2.30, .8, 400, 2500), (3.25, .55, 600, 3500), (3.9, .5, 800, 4000), (4.9, .7, 500, 2600),
           (6.35, .9, 400, 3800), (8.0, .9, 500, 3000), (9.45, .9, 700, 4200), (13.4, .9, 500, 5000)]
    for i, (t, d, a, b) in enumerate(cam): place(SFX, whoosh(d, a, b), t, .45, pan=(-0.5 if i % 2 else 0.5))
    hops = [(2.4, 3.1), (3.35, 3.8), (3.95, 4.4), (4.55, 4.95), (5.1, 5.6), (6.5, 7.3), (9.6, 10.3), (14.0, 14.75)]
    for i, (a, b) in enumerate(hops):
        place(SFX, boing(), a, .5); place(SFX, pop(620 + i * 45, 170), b, .7, pan=0.15 * (i % 3 - 1))
    for t in (4.45, 5.65): place(SFX, click(), t, .6); place(SFX, bell(1318.5, .5), t, .22)
    # glow dipilih
    place(SFX, whoosh(.9, 1000, 6000), 7.2, .35)
    for i, f in enumerate([1568, 2093, 2637, 3136]): place(SFX, bell(f, .9), 7.35 + i * .07, .22, pan=-.3 + i * .2)
    # ketik
    for i in range(6): place(SFX, click(), 6.2 + i / 8.5, .22)
    for i, ch in enumerate("Hi, I'm Armuzz"):
        if ch != " ": place(SFX, click(), 10.8 + i / 12, .12)
    for i, ch in enumerate("Code it. Stream it. Ship it."):
        if ch != " ": place(SFX, click(), 11.9 + i / 12, .12)
    for i, ch in enumerate("Hi, I'm Armuzz"):
        if ch != " ": place(SFX, click(), 21.9 + i / 12, .10)
    for i, ch in enumerate("Code it. Stream it. Ship it."):
        if ch != " ": place(SFX, click(), 22.6 + i / 16, .10)
    for i, ch in enumerate("armuzzdev.infinityfreeapp.com"):
        place(SFX, click(), 24.7 + i / 30, .07)
    # keyframe ping (pentatonic C minor)
    pent = [523.25, 622.25, 698.46, 783.99, 932.33, 1046.5]; n = 0
    for row in [[3, 8, 12, 16, 20, 24], [11, 13, 17, 19, 22, 25], [6, 9, 14, 18, 21], [2, 10, 15, 23]]:
        for s in row:
            xd = 540 + s * (2500 - 540) / 27
            tp = play_x_time(xd)
            if tp and 10.4 < tp < 14.2:
                place(SFX, bell(pent[n % len(pent)], .6), tp, .12, pan=((n % 5) - 2) * .2); n += 1
    # drop
    place(SFX, riser(2.3), DROP - 2.3, .55)
    place(SFX, whoosh(.45, 600, 7000), DROP - .5, .4)
    place(SFX, pop(1200, 300, .3), 15.15, .6)
    place(SFX, boom(), DROP, 1.0)
    place(SFX, whoosh(.8, 500, 5000), 15.4, .35)
    for t in rng.uniform(15.4, 17.6, 26): place(SFX, bell(float(rng.uniform(1500, 4500)), .5), float(t), .05, pan=float(rng.uniform(-.8, .8)))
    for i in range(3): place(SFX, pop(1000 + i * 150, 400, .2), 18.2 + i * .25, .3); place(SFX, bell(1760 + i * 220, .6), 18.2 + i * .25, .1)
    place(SFX, whoosh(.5, 800, 4000), 16.4, .25); place(SFX, bell(1568, .9), 16.5, .14); place(SFX, bell(1760, .9), 17.35, .12)
    for i, ch in enumerate('Arya Musthofa Roja'):
        if ch != ' ': place(SFX, click(), 24.0 + i / 28, .08)
    # disperse + akhir
    place(SFX, downlifter(2.0), 19.6, .45)
    place(SFX, boom(2.0), 24.4, .12)

def master(path_out, music=None):
    build_sfx()
    if music:
        raw = subprocess.run(["ffmpeg", "-v", "error", "-i", music, "-t", str(DUR), "-f", "f32le", "-ac", "2", "-ar", str(SR), "-"],
                             capture_output=True).stdout
        m = np.frombuffer(raw, np.float32).reshape(-1, 2)[:N]
        for ch in range(2): BED[ch][:len(m)] = m[:, ch] * 0.7
    else:
        build_bed()
    mix = [BED[c] * 0.55 + SFX[c] * 0.9 for c in range(2)]
    out = np.stack(mix, 1)
    tt = np.arange(N) / SR
    out *= np.minimum(1, tt / 0.15)[:, None] * np.minimum(1, (DUR - tt) / 0.7)[:, None]
    out = np.tanh(out * 1.1) / 1.1
    out = out / max(1e-6, np.abs(out).max()) * 0.89
    wavfile.write(path_out, SR, (out * 32767).astype(np.int16))
    for s in range(0, 27, 3):
        seg = out[s * SR:(s + 3) * SR]; print(f"{s:2d}-{s+3:2d}s rms={np.sqrt((seg**2).mean()):.3f} peak={np.abs(seg).max():.2f}")

if __name__ == "__main__":
    master(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else None)
