# Armuzz Intro — catatan pengembangan v1.1

## Yang diperbaiki

- Pembatas sudut kamera di `make_cam()` diubah dari langkah diskret 10% menjadi binary search kontinu. Tujuannya mengurangi kemungkinan snap saat kamera mendekati batas proyeksi, terutama di rentang gerakan kamera yang sebelumnya dicurigai mengalami glitch.
- Sisa label internal `Randy X` dibersihkan dan nama aset contoh di panel proyek diganti menjadi `armuzz_symbol.svg`.

## Yang belum diklaim selesai

- Perbaikan kamera sudah dicek secara sintaks dan melalui sampel numerik, tetapi belum dibuktikan lewat render penuh 27 detik.
- Video referensi GetShared belum berhasil diunduh dari lingkungan ini. Karena itu, kesamaan gaya dengan video referensi belum bisa dinilai secara frame-by-frame.
- Musik yang ada masih berupa musik sintetis bawaan proyek. Belum memakai trek komersial tertentu.

## Fokus pengembangan berikutnya

1. Render ulang rentang 9–15 detik untuk membandingkan kelancaran kamera sebelum dan sesudah patch.
2. Review posisi maskot pada beberapa perpindahan kamera; ada frame contoh yang memperlihatkan maskot terlalu dekat dengan tepi atas.
3. Setelah referensi dapat ditinjau, sesuaikan pacing, tipografi, komposisi, dan sound design berdasarkan pengamatan nyata.
