import numpy as np
from PIL import Image, ImageFilter
from scipy.ndimage import label, gaussian_filter, binary_dilation, binary_fill_holes

im = Image.open('cutout_raw.png').convert('RGBA'); a = np.array(im)
R, G, B, A = [a[..., i].astype(int) for i in range(4)]
a[..., 3][(B > R + 35) & (B > G + 15) & (A > 0)] = 0
lab, n = label(a[..., 3] > 40); sizes = np.bincount(lab.ravel()); sizes[0] = 0
a[..., 3] = np.where(lab == sizes.argmax(), a[..., 3], 0)
al = gaussian_filter(a[..., 3].astype(np.float32), 1.5)
a[..., 3] = np.clip((al - 90) * 255 / 100, 0, 255).astype(np.uint8)
im = Image.fromarray(a); bb = im.getbbox()
im = im.crop((bb[0], bb[1], bb[2], 2000))
S = 420 / im.height; im = im.resize((int(im.width * S), 420), Image.LANCZOS)
# bersihkan sisa banner di dekat tangan kiri (bukan warna kulit / bukan gelap)
b = np.array(im); r, g, bl = [b[..., i].astype(int) for i in range(3)]
skin = (r > g) & (g > bl - 5) & (r > 110)
regA = np.zeros(skin.shape, bool); regA[:215, :46] = True
regB = np.zeros(skin.shape, bool); regB[:215, :105] = True
junk = (~skin & regA) | ((bl > r + 8) & (r < 140) & regB) | ((r + g + bl > 600) & ~skin & regB)
b[..., 3][junk] = 0
lab, n = label(b[..., 3] > 40); sizes = np.bincount(lab.ravel()); sizes[0] = 0
b[..., 3] = np.where(lab == sizes.argmax(), b[..., 3], 0)
b[..., 3] = np.where(binary_fill_holes(b[..., 3] > 40) & (b[..., 3] < 255) & (b[..., 3] > 0), b[..., 3], b[..., 3])
im = Image.fromarray(b); pad = 34
canvas = Image.new('RGBA', (im.width + 2 * pad, im.height + 2 * pad), (0, 0, 0, 0)); canvas.paste(im, (pad, pad))
alpha = np.array(canvas.getchannel('A')) > 60
st = binary_dilation(alpha, iterations=7)
stroke = Image.new('RGBA', canvas.size, (255, 255, 255, 255)); stroke.putalpha(Image.fromarray((st * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(1.2)))
gl = binary_dilation(alpha, iterations=16)
glow = Image.new('RGBA', canvas.size, (255, 52, 78, 255)); glow.putalpha(Image.fromarray((gl * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(10)).point(lambda v: int(v * .9)))
out = Image.alpha_composite(glow, stroke); out = Image.alpha_composite(out, canvas)
out.save('mascot_arya.png'); print(out.size, 'anchor', out.width // 2, pad + 420)
bgc = Image.new('RGBA', out.size, (22, 12, 16, 255)); bgc.alpha_composite(out); bgc.convert('RGB').save('mascot_preview.jpg', quality=90)
