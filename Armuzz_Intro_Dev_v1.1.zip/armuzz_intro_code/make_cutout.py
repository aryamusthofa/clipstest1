# Langkah 0: potong latar dari foto -> cutout_raw.png  (pip install rembg onnxruntime)
import sys
from rembg import remove, new_session
from PIL import Image
src = sys.argv[1] if len(sys.argv) > 1 else "foto.jpg"
remove(Image.open(src).convert("RGB"), session=new_session("u2net_human_seg")).save("cutout_raw.png")
print("cutout_raw.png siap")
