#!/usr/bin/env bash
# Render per potongan, lanjutkan dari chunk valid, lalu gabungkan dengan audio.
# Pakai: bash render_all.sh [musik.mp3]
set -Eeuo pipefail
CALLER_DIR="$PWD"
MUSIC="${1:-}"
if [[ -n "$MUSIC" && "$MUSIC" != /* ]]; then MUSIC="$CALLER_DIR/$MUSIC"; fi
cd "$(dirname "$0")"

mkdir -p chunks

render_chunk() {
  local start="$1" end="$2" out="$3" expected actual
  expected="$(awk -v a="$start" -v b="$end" 'BEGIN { printf "%.6f", (b-a)/30 }')"

  if [[ -s "$out" ]]; then
    actual="$(ffprobe -v error -show_entries format=duration -of csv=p=0 "$out" 2>/dev/null || echo 0)"
    if awk -v a="$actual" -v e="$expected" 'BEGIN { exit !(a > 0 && (a-e < 0.08) && (e-a < 0.08)) }'; then
      echo "Lewati $out (sudah valid: ${actual}s)"
      return
    fi
    echo "Chunk $out tidak lengkap; render ulang."
    rm -f "$out"
  fi

  echo "Render frame $start sampai $end -> $out"
  python3 armuzz_intro.py chunk "$start" "$end" "$out"
  actual="$(ffprobe -v error -show_entries format=duration -of csv=p=0 "$out")"
  awk -v a="$actual" -v e="$expected" 'BEGIN { exit !(a > 0 && (a-e < 0.08) && (e-a < 0.08)) }' \
    || { echo "Durasi chunk tidak sesuai: $out ($actual s; harap $expected s)" >&2; exit 1; }
}

render_chunk 0   200 chunks/c0.mp4
render_chunk 200 400 chunks/c1.mp4
render_chunk 400 600 chunks/c2.mp4
render_chunk 600 810 chunks/c3.mp4

printf "file 'chunks/c0.mp4'\nfile 'chunks/c1.mp4'\nfile 'chunks/c2.mp4'\nfile 'chunks/c3.mp4'\n" > list.txt
ffmpeg -y -v error -f concat -safe 0 -i list.txt -c copy -movflags +faststart silent.mp4

if [[ -n "$MUSIC" ]]; then
  python3 armuzz_audio.py audio.wav "$MUSIC"
else
  python3 armuzz_audio.py audio.wav
fi

ffmpeg -y -v warning -i silent.mp4 -i audio.wav \
  -c:v libx264 -preset veryfast -crf 19 -pix_fmt yuv420p \
  -c:a aac -b:a 192k -af "loudnorm=I=-14:TP=-1.5:LRA=11" \
  -movflags +faststart -shortest armuzz_intro.tmp.mp4
mv -f armuzz_intro.tmp.mp4 armuzz_intro.mp4

echo "Selesai: armuzz_intro.mp4"
