# Armuzz Intro — motion graphics dari kode

Proyek intro personal Armuzz yang dirender secara programatis menggunakan Python, Pillow, NumPy, SciPy, dan FFmpeg.

## Kebutuhan

- Python 3
- `pillow`, `numpy`, `scipy`
- FFmpeg tersedia di PATH
- Font Inter (atur `INTER_DIR` bila lokasinya berbeda)
- FreeSerif atau DejaVu Serif
- `rembg` dan `onnxruntime` hanya diperlukan bila ingin membuat ulang cutout foto

Instal paket Python:

```bash
pip install pillow numpy scipy rembg onnxruntime
```

## Menjalankan

Dari folder proyek:

```bash
python3 armuzz_intro.py still 5.0 10.0 13.5 16.8 26.0
bash render_all.sh [musik.mp3]
```

Tanpa musik eksternal, audio dibuat dari sintesis internal. Bila memberi file musik, pastikan file tersebut memang boleh digunakan untuk video yang akan dipublikasikan.

## Peta kode

- `build_static()` — UI editor 2560×1440 yang digambar sekali.
- `Cam`, `warp_sheet()` — kamera 3D dan proyeksi perspektif.
- `KT`, `KV`, `CF` — keyframe kamera yang dihaluskan dengan PCHIP.
- `make_cam()` — pembatas kamera kontinu untuk menghindari perubahan sudut diskret.
- `HOPS`, `mascot_state()` — lintasan gerak maskot dan squash-and-stretch.
- `scene_frame()` — visual isi viewer, transisi warna, partikel, dan teks.
- `armuzz_audio.py` — musik sintetis dan efek suara yang disinkronkan ke visual.

## Status

Preview sebelumnya berdurasi 27 detik, 1280×720, 30 fps. Patch v1.1 memperbaiki logika pembatas sudut kamera, tetapi harus dirender ulang untuk memastikan hasil visual akhirnya. Lihat `DEV_NOTES.md` untuk catatan validasi dan pekerjaan berikutnya.
